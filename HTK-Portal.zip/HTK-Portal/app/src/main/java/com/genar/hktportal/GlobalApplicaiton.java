package com.genar.hktportal;

import android.app.Application;

public class GlobalApplicaiton extends Application {

    public static String TOP_LIST_COUNT;

    public GlobalApplicaiton() {

    }
}
